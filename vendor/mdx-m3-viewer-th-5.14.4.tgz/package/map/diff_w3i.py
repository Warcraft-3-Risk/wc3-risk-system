"""Field-by-field diff for war3map.w3i files.

Usage:
    python diff_w3i.py OLD.w3i NEW.w3i
    python diff_w3i.py FILE.w3i            (single file -> dump all fields)

Parses both files with the known v25..v39 layout (mirrors
src/parsers/w3x/w3i/file.ts and player.ts) and reports every field whose
value changed, together with its byte offset.

Fields whose names say "unknown" are not identified yet. To name them:
    1. Open the map in the World Editor and change ONE option (or one player's
       HUD Skin, etc.).
    2. Save, then extract/export war3map.w3i again.
    3. Run:  python diff_w3i.py previous.w3i newly_exported.w3i
The changed field(s) will tell you exactly what that option maps to.
"""

import struct
import sys


class Reader:
    def __init__(self, data, name):
        self.data = data
        self.pos = 0
        self.name = name
        self.fields = []  # (label, offset, size, value)

    def _read(self, fmt, size, label):
        off = self.pos
        if off + size > len(self.data):
            raise EOFError(f"[{self.name}] want {size} bytes at {off} for {label}, "
                           f"only {len(self.data) - off} left")
        vals = struct.unpack_from(fmt, self.data, off)
        self.pos += size
        value = vals[0] if len(vals) == 1 else list(vals)
        self.fields.append((label, off, size, value))
        return value

    def i32(self, label):
        return self._read('<i', 4, label)

    def u32(self, label):
        return self._read('<I', 4, label)

    def f32(self, label):
        return self._read('<f', 4, label)

    def u8(self, label):
        return self._read('<B', 1, label)

    def u32bits(self, label):
        """Like u32, but the stored value is annotated with hex for bitmask fields."""
        value = self._read('<I', 4, label)
        _, off, size, _ = self.fields[-1]
        self.fields[-1] = (label, off, size, f'{value} (0x{value:08X})')
        return value

    def u8arr(self, n, label):
        return self.bytes(n, label)

    def bytes(self, n, label):
        off = self.pos
        if off + n > len(self.data):
            raise EOFError(f"[{self.name}] want {n} bytes at {off} for {label}, "
                           f"only {len(self.data) - off} left")
        value = list(self.data[off:off + n])
        self.pos += n
        self.fields.append((label, off, n, value))
        return value

    def arr_i32(self, n, label):
        return [self.i32(f"{label}[{i}]") for i in range(n)]

    def arr_u32(self, n, label):
        return [self.u32(f"{label}[{i}]") for i in range(n)]

    def arr_f32(self, n, label):
        return [self.f32(f"{label}[{i}]") for i in range(n)]

    def cstr(self, label):
        off = self.pos
        end = self.data.find(b'\x00', off)
        if end < 0:
            raise EOFError(f"[{self.name}] unterminated string at {off} for {label}")
        raw = self.data[off:end]
        self.pos = end + 1
        value = raw.decode('utf-8', 'replace')
        self.fields.append((label, off, self.pos - off, value))
        return value


def parse(path):
    data = open(path, 'rb').read()
    r = Reader(data, path)

    version = r.i32('version')
    r.i32('saves')
    r.i32('editorVersion')

    if version > 27:
        r.arr_u32(4, 'buildVersion')

    r.cstr('name')
    r.cstr('author')
    r.cstr('description')
    r.cstr('recommendedPlayers')
    r.arr_f32(8, 'cameraBounds')
    r.arr_i32(4, 'cameraBoundsComplements')
    r.arr_i32(2, 'playableSize')
    r.u32bits('flags')
    r.u8('tileset')
    r.i32('campaignBackground')

    if version >= 39:
        r.i32('unknown2 (NEW: 64)')

    if version > 24:
        r.cstr('loadingScreenModel')
    r.cstr('loadingScreenText')
    r.cstr('loadingScreenTitle')
    r.cstr('loadingScreenSubtitle')
    r.i32('loadingScreen')

    if version > 24:
        r.cstr('prologueScreenModel')
    r.cstr('prologueScreenText')
    r.cstr('prologueScreenTitle')
    r.cstr('prologueScreenSubtitle')

    if version > 24:
        r.i32('fogStyle (0 = Linear)')
        r.arr_f32(2, 'fogHeight (zStart/zEnd)')
        r.f32('fogDensity')
        r.bytes(4, 'fogColor')
        if version >= 39:
            r.f32('fogHeightStart')
            r.f32('fogHeightEnd')
            r.f32('fogLinearStart')
            r.f32('fogLinearEnd')
            r.f32('fogMaxOpacity')
            r.i32('fogUnknown (draw fog over sky?)')
        r.i32('globalWeather')
        r.cstr('soundEnvironment')
        r.u8('lightEnvironmentTileset')
        r.bytes(4, 'waterVertexColor')

    if version > 27:
        r.u32('scriptMode')
    if version > 30:
        r.u32bits('graphicsMode (supported modes: 1=SD, 2=HD, 4=DE)')
        r.u32('unknown1')
    if version > 32:
        r.u32('defaultCameraZoom')
        r.u32('maxCameraZoom')
        r.u32('minCameraZoom')

    if version >= 39:
        r.arr_i32(9, 'unknown4')
        r.i32('unknown4[9] (alpha tile minimap color, ARGB)')

    players = r.i32('playerCount')
    for i in range(players):
        p = f'players[{i}]'
        r.i32(f'{p}.id')
        r.i32(f'{p}.type')
        r.i32(f'{p}.race')
        if version >= 39:
            r.i32(f'{p}.hudSkin')
        r.i32(f'{p}.isFixedStartPosition')
        r.cstr(f'{p}.name')
        r.f32(f'{p}.startLocation[0]')
        r.f32(f'{p}.startLocation[1]')
        r.u32(f'{p}.allyLowPriorities')
        r.u32(f'{p}.allyHighPriorities')
        if version > 30:
            r.bytes(8, f'{p}.unknown1')

    forces = r.i32('forceCount')
    for i in range(forces):
        f = f'forces[{i}]'
        r.u32(f'{f}.flags')
        r.u32(f'{f}.playerMasks')
        r.cstr(f'{f}.name')

    upgrades = r.i32('upgradeAvailabilityChangeCount')
    for i in range(upgrades):
        r.arr_u32(4, f'upgradeAvailabilityChanges[{i}]')

    techs = r.i32('techAvailabilityChangeCount')
    for i in range(techs):
        r.arr_u32(2, f'techAvailabilityChanges[{i}]')

    r.i32('randomUnitTableCount')

    if version > 24:
        r.i32('randomItemTableCount')

    if r.pos < len(r.data):
        r.bytes(len(r.data) - r.pos, 'trailing (unparsed)')

    return r, version


def dump(path):
    r, version = parse(path)
    print(f"{path}  (version {version}, {len(r.data)} bytes)")
    print('-' * 78)
    for label, off, size, value in r.fields:
        print(f"  {off:5d}  {size:3d}  {label:<44} {value!r}")
    print(f"\n  parsed {r.pos} / {len(r.data)} bytes")


def diff(path_a, path_b):
    ra, va = parse(path_a)
    rb, vb = parse(path_b)

    print(f"A: {path_a}  (version {va}, {len(ra.data)} bytes)")
    print(f"B: {path_b}  (version {vb}, {len(rb.data)} bytes)")
    print('-' * 78)

    fa, fb = ra.fields, rb.fields
    changes = 0

    for i in range(max(len(fa), len(fb))):
        a = fa[i] if i < len(fa) else None
        b = fb[i] if i < len(fb) else None

        if a and b and a[0] == b[0] and a[3] == b[3]:
            continue

        changes += 1

        a_txt = f"@{a[1]:<5} {a[3]!r}" if a else '<missing>'
        b_txt = f"@{b[1]:<5} {b[3]!r}" if b else '<missing>'
        label = (b or a)[0]

        print(f"  {label}")
        print(f"      A: {a_txt}")
        print(f"      B: {b_txt}")

    if changes == 0:
        print("  No field differences.")

    print('-' * 78)
    print(f"  {changes} changed field(s)")
    print(f"  size: {len(ra.data)} -> {len(rb.data)} ({len(rb.data) - len(ra.data):+d})")


def main():
    args = sys.argv[1:]

    if len(args) == 1:
        dump(args[0])
    elif len(args) == 2:
        diff(args[0], args[1])
    else:
        print(__doc__)


if __name__ == '__main__':
    main()
